
exports.obj = {
  'effects' : []
  'add' : function(eff) {
    this.effects.push(eff)
    return this
  }
}

